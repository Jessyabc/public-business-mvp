import { Brainstorm, BrainstormConnection } from "@/types/brainstorm";

// This file is kept for type definitions - mock data removed
// Real data now comes from Supabase database via posts table
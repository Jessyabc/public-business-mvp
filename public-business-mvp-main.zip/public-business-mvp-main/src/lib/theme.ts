/**
 * PublicBusiness Brand Tokens
 */
export const PB = {
  blue: '#489FE3',
  aqua: '#67FFD8',
  whiteHot: '#E8F7FF',
} as const;

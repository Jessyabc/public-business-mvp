// This file is deprecated - use @/integrations/supabase/client instead
export { supabase } from '@/integrations/supabase/client';
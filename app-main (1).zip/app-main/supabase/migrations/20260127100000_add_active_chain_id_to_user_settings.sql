-- Migration: Add active_chain_id to user_settings
-- Production Blocker for Think Space V1 Sticky Active Chain

-- 1. Add active_chain_id column (nullable uuid)
ALTER TABLE user_settings
ADD COLUMN IF NOT EXISTS active_chain_id uuid;

-- 2. Add foreign key constraint with ON DELETE SET NULL
-- This ensures if a chain is deleted, the active_chain_id becomes null gracefully
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints
    WHERE constraint_name = 'user_settings_active_chain_id_fkey'
    AND table_name = 'user_settings'
  ) THEN
    ALTER TABLE user_settings
    ADD CONSTRAINT user_settings_active_chain_id_fkey
    FOREIGN KEY (active_chain_id) REFERENCES thought_chains(id)
    ON DELETE SET NULL;
  END IF;
END $$;

-- 3. RLS Policy Updates for user_settings
-- Ensure upsert-on-demand works: user can INSERT/UPDATE/SELECT their own row

-- Drop existing policies if they exist (to recreate them cleanly)
DROP POLICY IF EXISTS "Users can view own settings" ON user_settings;
DROP POLICY IF EXISTS "Users can insert own settings" ON user_settings;
DROP POLICY IF EXISTS "Users can update own settings" ON user_settings;

-- Create comprehensive RLS policies
CREATE POLICY "Users can view own settings"
ON user_settings FOR SELECT
TO authenticated
USING (user_id = auth.uid());

CREATE POLICY "Users can insert own settings"
ON user_settings FOR INSERT
TO authenticated
WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can update own settings"
ON user_settings FOR UPDATE
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

-- 4. Create index for active_chain_id lookups
CREATE INDEX IF NOT EXISTS idx_user_settings_active_chain_id
ON user_settings(active_chain_id)
WHERE active_chain_id IS NOT NULL;

-- 5. Comment for documentation
COMMENT ON COLUMN user_settings.active_chain_id IS 
'FK to thought_chains.id - the currently active chain for Think Space. ON DELETE SET NULL ensures graceful handling when chain is deleted.';

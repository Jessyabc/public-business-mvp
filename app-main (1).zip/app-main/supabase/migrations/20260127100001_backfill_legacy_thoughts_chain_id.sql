-- Migration: Backfill legacy thoughts with null chain_id
-- Ensures core invariant: no thought without chain_id
--
-- Strategy:
-- 1. For each user with null chain_id thoughts, find or create a "legacy" chain
-- 2. Assign all null chain_id thoughts to that legacy chain
-- 3. Set first_thought_at on the chain based on earliest thought

-- Step 1: Create legacy chains for users who have thoughts with null chain_id
-- but don't have any existing chain
INSERT INTO thought_chains (id, user_id, created_at, updated_at, first_thought_at, display_label)
SELECT 
  gen_random_uuid(),
  wt.user_id,
  MIN(COALESCE(wt.anchored_at, wt.created_at)),
  NOW(),
  MIN(COALESCE(wt.anchored_at, wt.created_at)),
  'Legacy thoughts'
FROM workspace_thoughts wt
WHERE wt.chain_id IS NULL
  AND NOT EXISTS (
    SELECT 1 FROM thought_chains tc WHERE tc.user_id = wt.user_id
  )
GROUP BY wt.user_id;

-- Step 2: Backfill null chain_id thoughts to their user's first chain
-- (either existing or the legacy chain we just created)
WITH user_first_chain AS (
  SELECT DISTINCT ON (user_id) 
    user_id,
    id as chain_id
  FROM thought_chains
  ORDER BY user_id, created_at ASC
)
UPDATE workspace_thoughts wt
SET 
  chain_id = ufc.chain_id,
  updated_at = NOW()
FROM user_first_chain ufc
WHERE wt.user_id = ufc.user_id
  AND wt.chain_id IS NULL;

-- Step 3: Update first_thought_at on chains that received backfilled thoughts
UPDATE thought_chains tc
SET first_thought_at = (
  SELECT MIN(COALESCE(wt.anchored_at, wt.created_at))
  FROM workspace_thoughts wt
  WHERE wt.chain_id = tc.id
)
WHERE tc.first_thought_at IS NULL
  AND EXISTS (
    SELECT 1 FROM workspace_thoughts wt WHERE wt.chain_id = tc.id
  );

-- Verification: This should return 0 after migration
-- SELECT COUNT(*) FROM workspace_thoughts WHERE chain_id IS NULL;

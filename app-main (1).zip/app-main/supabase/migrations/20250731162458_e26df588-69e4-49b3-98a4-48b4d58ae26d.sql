-- Add business_member role to existing enum (requires separate transaction)
ALTER TYPE app_role ADD VALUE 'business_member';
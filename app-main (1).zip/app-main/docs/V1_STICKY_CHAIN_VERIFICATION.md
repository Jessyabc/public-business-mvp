# Think Space V1 - Sticky Active Chain Verification Checklist

## Phase 1-2 Complete - Run These DB Queries to Verify

### 1) Column Exists Verification
```sql
SELECT column_name, data_type
FROM information_schema.columns
WHERE table_name = 'user_settings'
  AND column_name = 'active_chain_id';
```
**Expected:** 1 row with `active_chain_id | uuid`

### 2) FK Exists Verification
```sql
SELECT
  tc.constraint_name,
  kcu.column_name,
  ccu.table_name AS foreign_table_name,
  ccu.column_name AS foreign_column_name
FROM information_schema.table_constraints AS tc
JOIN information_schema.key_column_usage AS kcu
  ON tc.constraint_name = kcu.constraint_name
JOIN information_schema.constraint_column_usage AS ccu
  ON ccu.constraint_name = tc.constraint_name
WHERE tc.table_name = 'user_settings'
  AND tc.constraint_type = 'FOREIGN KEY'
  AND kcu.column_name = 'active_chain_id';
```
**Expected:** 1 row showing FK to `thought_chains.id`

### 3) Orphan Guard Query (after testing with USER_ID)
```sql
SELECT COUNT(*) AS orphan_count
FROM user_settings us
LEFT JOIN thought_chains tc ON tc.id = us.active_chain_id
WHERE us.user_id = 'USER_ID_HERE'
  AND us.active_chain_id IS NOT NULL
  AND tc.id IS NULL;
```
**Expected:** `0`

### 4) Core Invariant - No Thought Without chain_id
```sql
-- All rows
SELECT COUNT(*) AS null_chain_count
FROM workspace_thoughts
WHERE user_id = 'USER_ID_HERE'
  AND chain_id IS NULL;
```
**Expected:** `0`

```sql
-- Anchored only
SELECT COUNT(*) AS null_chain_count
FROM workspace_thoughts
WHERE user_id = 'USER_ID_HERE'
  AND state = 'anchored'
  AND chain_id IS NULL;
```
**Expected:** `0`

```sql
-- Drafts/active only
SELECT COUNT(*) AS null_chain_count
FROM workspace_thoughts
WHERE user_id = 'USER_ID_HERE'
  AND state = 'active'
  AND chain_id IS NULL;
```
**Expected:** `0`

### 5) At Least One Chain Exists
```sql
SELECT COUNT(*) AS chain_count
FROM thought_chains
WHERE user_id = 'USER_ID_HERE';
```
**Expected:** `>= 1`

### 6) Chain Distribution Sanity
```sql
SELECT chain_id, COUNT(*) AS thought_count
FROM workspace_thoughts
WHERE user_id = 'USER_ID_HERE'
GROUP BY chain_id
ORDER BY thought_count DESC;
```
**Expected:** Shows chain distribution

### 7) Chain Ordering Verification (by thought event_time)
```sql
SELECT
  chain_id,
  MAX(COALESCE(anchored_at, created_at)) AS last_event_time,
  COUNT(*) AS thought_count
FROM workspace_thoughts
WHERE user_id = 'USER_ID_HERE'
GROUP BY chain_id
ORDER BY last_event_time DESC;
```
**Expected:** Chains ordered by most recent thought event_time

---

## Manual QA Tests

### No Settings Row Test (Upsert-on-Demand)
1. Delete your `user_settings` row (or use a new account)
2. Open Think Space
3. Confirm:
   - A deterministic chain is selected
   - `user_settings` row is created with `active_chain_id`
4. Refresh — confirm the same chain is active

### Pull-to-Break Test
1. Scroll past open circle 20 times → 0 accidental breaks
2. Pull-to-break 10 times → 10/10 success
3. Start scrolling near the circle (not on it) → no break
4. Confirm new chain is created and becomes active immediately

### Chain Indicator Truth
- "Writing to: X" matches the active chain
- Updates on chain switch, pull-to-break, and refresh/login

---

## Files Modified/Created

### Migration
- `/app/supabase/migrations/20260127100000_add_active_chain_id_to_user_settings.sql`

### TypeScript Types
- `/app/src/integrations/supabase/types.ts` - Added `active_chain_id` to `user_settings`

### Persistence Hook
- `/app/src/features/workspace/hooks/useActiveChainPersistence.ts` - NEW

### Components
- `/app/src/features/workspace/components/ChainsList.tsx` - NEW (All Chains View)
- `/app/src/features/workspace/components/ThoughtStack.tsx` - Added Chains button
- `/app/src/features/workspace/components/WorkspaceCanvas.tsx` - Integrated persistence hook, chain_id enforcement
- `/app/src/features/workspace/components/ChainThread.tsx` - Updated createThought call

### Stores/Types
- `/app/src/features/workspace/useWorkspaceStore.ts` - createThought accepts chainId
- `/app/src/features/workspace/types.ts` - Updated createThought signature

### Exports
- `/app/src/features/workspace/index.ts` - Exported new components/hooks

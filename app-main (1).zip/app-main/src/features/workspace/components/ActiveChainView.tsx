/**
 * Think Space V1: Active Chain View
 * 
 * Chain-first mental model:
 * - Shows ONLY thoughts from the active chain
 * - Ordered by COALESCE(anchored_at, created_at), id
 * - Days appear as subtle separators, NOT primary grouping
 * - Pull-to-break creates new chain at top
 */

import { useMemo, useCallback, useRef, useState } from 'react';
import { useWorkspaceStore } from '../useWorkspaceStore';
import { useChainStore } from '../stores/chainStore';
import { useAuth } from '@/contexts/AuthContext';
import { cn } from '@/lib/utils';
import { format, parseISO, isToday, isYesterday, isThisWeek, isThisYear, isSameDay } from 'date-fns';
import { Link2, Plus } from 'lucide-react';
import { ChainsList } from './ChainsList';
import { AnchoredThought } from './AnchoredThought';
import { OpenCircle } from './OpenCircle';
import type { ThoughtObject } from '../types';

// PB Blue - active cognition indicator
const PB_BLUE = '#489FE3';

interface ActiveChainViewProps {
  onStartThinking: () => void;
}

/**
 * Format day label for subtle day separators
 */
function formatDayLabel(dateStr: string): string {
  const date = parseISO(dateStr);
  if (isToday(date)) return 'Today';
  if (isYesterday(date)) return 'Yesterday';
  if (isThisWeek(date)) return format(date, 'EEEE');
  if (isThisYear(date)) return format(date, 'MMMM d');
  return format(date, 'MMMM d, yyyy');
}

/**
 * Get event time for ordering: COALESCE(anchored_at, created_at)
 */
function getEventTime(thought: ThoughtObject): number {
  return new Date(thought.anchored_at || thought.created_at).getTime();
}

/**
 * Get day key from event time
 */
function getDayFromEventTime(thought: ThoughtObject): string {
  const eventTime = thought.anchored_at || thought.created_at;
  return format(parseISO(eventTime), 'yyyy-MM-dd');
}

export function ActiveChainView({ onStartThinking }: ActiveChainViewProps) {
  const { user } = useAuth();
  const { thoughts, createThought } = useWorkspaceStore();
  const { 
    chains,
    activeChainId, 
    getChainById, 
    setActiveChain,
    createChain,
    breakChain,
  } = useChainStore();
  
  const [isChainsListOpen, setIsChainsListOpen] = useState(false);
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  
  // Get active chain details
  const activeChain = activeChainId ? getChainById(activeChainId) : null;
  const chainLabel = activeChain?.display_label || 'Current chain';
  
  /**
   * Filter and sort thoughts for active chain
   * Order by COALESCE(anchored_at, created_at) DESC, id DESC (most recent first)
   */
  const chainThoughts = useMemo(() => {
    if (!activeChainId) return [];
    
    return thoughts
      .filter(t => t.chain_id === activeChainId && t.state === 'anchored')
      .sort((a, b) => {
        const timeA = getEventTime(a);
        const timeB = getEventTime(b);
        if (timeB !== timeA) return timeB - timeA; // Most recent first
        return b.id.localeCompare(a.id); // Tie-breaker
      });
  }, [thoughts, activeChainId]);

  /**
   * Group thoughts with day separators (for visual only, not structural)
   * Returns array of { type: 'day' | 'thought', ... }
   */
  const thoughtsWithDaySeparators = useMemo(() => {
    const result: Array<
      | { type: 'day'; dayKey: string; label: string }
      | { type: 'thought'; thought: ThoughtObject }
    > = [];
    
    let lastDayKey: string | null = null;
    
    for (const thought of chainThoughts) {
      const dayKey = getDayFromEventTime(thought);
      
      // Add day separator if new day
      if (dayKey !== lastDayKey) {
        result.push({
          type: 'day',
          dayKey,
          label: formatDayLabel(thought.anchored_at || thought.created_at),
        });
        lastDayKey = dayKey;
      }
      
      result.push({ type: 'thought', thought });
    }
    
    return result;
  }, [chainThoughts]);

  // Handle pull-to-break
  const handleBreakChain = useCallback(() => {
    if (!user) return;
    
    // Create new chain and set as active
    breakChain(user.id);
    
    // The breakChain function already:
    // 1. Creates a new chain
    // 2. Sets it as active
    // 3. The persistence hook will save to user_settings
  }, [user, breakChain]);

  // Handle chain selection from list
  const handleChainSelect = useCallback((chainId: string) => {
    setActiveChain(chainId);
    setIsChainsListOpen(false);
  }, [setActiveChain]);

  // Total chain count for navigation
  const chainCount = chains.length;

  return (
    <div className="active-chain-view w-full" ref={scrollContainerRef}>
      {/* Chain Header - Always visible */}
      <div className="sticky top-0 z-30 bg-[#F5F0EB]/95 backdrop-blur-sm pb-3 pt-2">
        <div className="flex items-center justify-between max-w-2xl mx-auto px-1">
          {/* Writing to indicator - ALWAYS shows active chain */}
          <div 
            className="flex items-center gap-2 px-3 py-1.5 rounded-full"
            style={{
              background: `${PB_BLUE}10`,
            }}
            data-testid="active-chain-indicator"
          >
            <div 
              className="w-2 h-2 rounded-full"
              style={{ background: PB_BLUE }}
            />
            <span 
              className="text-sm font-medium"
              style={{ color: PB_BLUE }}
            >
              Writing to: {chainLabel}
            </span>
          </div>
          
          {/* Chain navigation */}
          <button
            onClick={() => setIsChainsListOpen(true)}
            className={cn(
              "flex items-center gap-2 px-3 py-1.5 rounded-full",
              "text-sm font-medium transition-all duration-200",
              "hover:scale-105 active:scale-95"
            )}
            style={{ 
              color: '#6B635B',
              background: '#EAE5E0',
            }}
            data-testid="open-chains-btn"
          >
            <Link2 className="w-4 h-4" />
            <span>{chainCount} chain{chainCount !== 1 ? 's' : ''}</span>
          </button>
        </div>
      </div>

      {/* Open Circle - Pull to break chain */}
      <div className="max-w-2xl mx-auto mb-6">
        <OpenCircle
          onContinue={onStartThinking}
          onBreak={handleBreakChain}
        />
      </div>

      {/* Chain Thoughts - Ordered by event_time */}
      <div className="max-w-2xl mx-auto space-y-1">
        {chainThoughts.length === 0 ? (
          <div className="text-center py-12">
            <p 
              className="text-sm opacity-50 mb-4"
              style={{ color: '#6B635B' }}
            >
              This chain is empty
            </p>
            <button
              onClick={onStartThinking}
              className="px-4 py-2 rounded-lg text-sm font-medium transition-all"
              style={{
                color: PB_BLUE,
                background: `${PB_BLUE}15`,
              }}
              data-testid="start-first-thought-btn"
            >
              Start thinking
            </button>
          </div>
        ) : (
          thoughtsWithDaySeparators.map((item, index) => {
            if (item.type === 'day') {
              return (
                <div 
                  key={`day-${item.dayKey}`}
                  className="flex items-center gap-3 py-3 mt-4 first:mt-0"
                >
                  {/* Subtle day separator - visual timestamp only */}
                  <div 
                    className="flex-1 h-px opacity-20"
                    style={{ background: '#A09890' }}
                  />
                  <span 
                    className="text-xs font-medium opacity-40 px-2"
                    style={{ color: '#6B635B' }}
                  >
                    {item.label}
                  </span>
                  <div 
                    className="flex-1 h-px opacity-20"
                    style={{ background: '#A09890' }}
                  />
                </div>
              );
            }
            
            return (
              <AnchoredThought
                key={item.thought.id}
                thought={item.thought}
              />
            );
          })
        )}
      </div>

      {/* Chains List Sidebar */}
      <ChainsList
        isOpen={isChainsListOpen}
        onClose={() => setIsChainsListOpen(false)}
      />
    </div>
  );
}

/**
 * Think Space V1: Workspace Canvas
 * 
 * Chain-first mental model:
 * - User is always inside one active chain
 * - Thoughts from other chains are hidden
 * - Pull-to-break creates new chain
 * - Sticky chain persists across refresh/login
 */

import { useCallback, useState, useEffect, useRef } from 'react';
import { useWorkspaceStore } from '../useWorkspaceStore';
import { useWorkspaceSync } from '../useWorkspaceSync';
import { useChainStore } from '../stores/chainStore';
import { useChainSync } from '../useChainSync';
import { useActiveChainPersistence } from '../hooks/useActiveChainPersistence';
import { ThinkingSurface } from './ThinkingSurface';
import { ActiveChainView } from './ActiveChainView';
import { EmptyWorkspace } from './EmptyWorkspace';
import { useAuth } from '@/contexts/AuthContext';
import { cn } from '@/lib/utils';

// Safety timeout for workspace loading (in case sync gets stuck)
const LOADING_TIMEOUT_MS = 15000;

export function WorkspaceCanvas() {
  const { user } = useAuth();
  const { 
    thoughts,
    isLoading,
    isSyncing,
    createThought,
    getActiveThought,
    activeDayKey,
    setActiveDayKey,
    setLoading,
  } = useWorkspaceStore();
  
  const { activeChainId, createChain } = useChainStore();
  
  // Prevent immediate re-open after blur closes the thought
  const justAnchoredRef = useRef(false);
  
  // Safety timeout for loading state
  const [loadingTimedOut, setLoadingTimedOut] = useState(false);
  
  useEffect(() => {
    if (!isLoading) {
      setLoadingTimedOut(false);
      return;
    }
    
    const timeoutId = window.setTimeout(() => {
      console.warn('WorkspaceCanvas: Loading timed out, forcing render');
      setLoadingTimedOut(true);
      // Also force the store to reset loading
      setLoading(false);
    }, LOADING_TIMEOUT_MS);
    
    return () => window.clearTimeout(timeoutId);
  }, [isLoading, setLoading]);
  
  // Track if user deliberately started thinking (for auto-focus)
  const [userInitiated, setUserInitiated] = useState(false);
  
  // Initialize sync for thoughts and chains
  useWorkspaceSync();
  useChainSync();
  
  // Initialize sticky active chain persistence
  useActiveChainPersistence();
  
  const activeThought = getActiveThought();
  const hasThoughts = thoughts.length > 0;
  const hasAnchoredThoughts = thoughts.some((t) => t.state === 'anchored');

  /**
   * Helper to ensure a chain exists before creating a thought
   * Core invariant: no thought without chain_id
   */
  const ensureChainAndCreateThought = useCallback(() => {
    let chainIdToUse = activeChainId;
    
    // If no active chain, create one
    if (!chainIdToUse && user) {
      chainIdToUse = createChain(user.id);
    }
    
    createThought(undefined, user?.id, chainIdToUse || undefined);
  }, [activeChainId, createChain, createThought, user]);

  const handleStartThinking = useCallback(() => {
    setUserInitiated(true);
    setActiveDayKey(null); // New thought = today
    ensureChainAndCreateThought();
  }, [ensureChainAndCreateThought, setActiveDayKey]);

  // Reset user-initiated flag when thought is anchored and prevent immediate re-open
  const handleAnchor = useCallback(() => {
    setUserInitiated(false);
    justAnchoredRef.current = true;
    // Reset after a short delay to allow click events to complete
    setTimeout(() => {
      justAnchoredRef.current = false;
    }, 100);
  }, []);

  // Handle canvas click (tap anywhere empty to start writing)
  const handleCanvasClick = useCallback((e: React.MouseEvent) => {
    // Prevent re-opening immediately after blur closed the thought
    if (justAnchoredRef.current) {
      return;
    }
    
    const target = e.target as HTMLElement;
    // Check if click is on an interactive element that should not trigger new thought
    const isOnThought = target.closest('.anchored-thought') || 
                        target.closest('.thinking-surface') ||
                        target.closest('.day-thread') ||
                        target.closest('button') ||
                        target.closest('input') ||
                        target.closest('textarea') ||
                        target.closest('a');
    
    if (!activeThought && !isOnThought) {
      setUserInitiated(true);
      setActiveDayKey(null); // New thought = today
      ensureChainAndCreateThought();
    }
  }, [activeThought, ensureChainAndCreateThought, setActiveDayKey]);

  // Global Enter key to start writing (when no thought is active)
  useEffect(() => {
    const handleGlobalKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      const isTyping = 
        target.tagName === 'INPUT' || 
        target.tagName === 'TEXTAREA' || 
        target.isContentEditable;
      
      if (e.key === 'Enter' && !activeThought && !isTyping && !e.metaKey && !e.ctrlKey && !e.shiftKey) {
        e.preventDefault();
        setUserInitiated(true);
        setActiveDayKey(null);
        ensureChainAndCreateThought();
      }
    };

    document.addEventListener('keydown', handleGlobalKeyDown);
    return () => document.removeEventListener('keydown', handleGlobalKeyDown);
  }, [activeThought, ensureChainAndCreateThought, setActiveDayKey]);

  // Show loading only if we're actually loading and haven't timed out
  if (isLoading && !loadingTimedOut) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <div className="text-[var(--text-tertiary)] opacity-60">...</div>
      </div>
    );
  }

  // Check if active chain has any thoughts
  const activeChainThoughts = thoughts.filter(
    t => t.chain_id === activeChainId && t.state === 'anchored'
  );
  const hasActiveChainThoughts = activeChainThoughts.length > 0;

  return (
    <div 
      className={cn(
        "workspace-canvas",
        "w-full min-h-screen",
        "px-4 pt-4 pb-32 md:px-8 md:pt-6 md:pb-36",
        !activeThought && hasActiveChainThoughts && "cursor-text"
      )}
      onClick={handleCanvasClick}
    >
      {/* Sync indicator - very subtle */}
      {isSyncing && (
        <div className="fixed top-4 right-4 z-50">
          <span className="text-xs text-[var(--text-tertiary)] opacity-30">
            ·
          </span>
        </div>
      )}

      <div className="max-w-3xl mx-auto space-y-6">
        {/* Active thinking area */}
        <section>
          {activeThought ? (
            <ThinkingSurface 
              thoughtId={activeThought.id}
              onAnchor={handleAnchor}
              autoFocus={userInitiated}
            />
          ) : !hasThoughts ? (
            <EmptyWorkspace onStartThinking={handleStartThinking} />
          ) : null}
        </section>

        {/* Active Chain View - Chain-first rendering */}
        {hasThoughts && (
          <section>
            <ActiveChainView onStartThinking={handleStartThinking} />
          </section>
        )}
      </div>
    </div>
  );
}

// Re-export from unified analytics system
export { analytics, useAnalytics } from '@/lib/analytics';

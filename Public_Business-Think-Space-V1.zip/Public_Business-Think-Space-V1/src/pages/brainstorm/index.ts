export { default as Discuss } from '@/pages/Discuss';

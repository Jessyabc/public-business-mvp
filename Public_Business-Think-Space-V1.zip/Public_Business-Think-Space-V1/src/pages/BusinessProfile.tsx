import { BusinessProfileForm } from '@/components/business/BusinessProfileForm';

export function BusinessProfile() {
  return <BusinessProfileForm />;
}

export default BusinessProfile;
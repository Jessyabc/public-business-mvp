import { ProfileForm } from '@/components/profile/ProfileForm';

export function UserProfile() {
  return <ProfileForm />;
}
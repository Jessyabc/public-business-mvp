/**
 * Think Space: Sticky Active Chain Persistence Hook
 * 
 * Handles persistence of active_chain_id to user_settings table.
 * Implements upsert-on-demand: creates row if missing.
 * 
 * Chain selection priority (when active_chain_id is null):
 * 1. Most recently updated chain by thought event_time (MAX(COALESCE(anchored_at, created_at)))
 * 2. Legacy/default chain
 * 3. Create a new chain
 */

import { useEffect, useCallback, useRef } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useChainStore } from '../stores/chainStore';
import { useWorkspaceStore } from '../useWorkspaceStore';
import type { ChainId } from '../types/chain';

const PERSISTENCE_DEBOUNCE_MS = 500;

export function useActiveChainPersistence() {
  const { user } = useAuth();
  const { 
    chains, 
    activeChainId, 
    setActiveChain, 
    createChain,
    setChains,
  } = useChainStore();
  const { thoughts } = useWorkspaceStore();
  
  const persistTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const isInitializedRef = useRef(false);
  const lastPersistedChainIdRef = useRef<string | null>(null);

  /**
   * Compute the most recently updated chain by thought event_time
   * Uses MAX(COALESCE(anchored_at, created_at)) grouped by chain_id
   */
  const getMostRecentChainByThoughtEventTime = useCallback((): ChainId | null => {
    if (chains.length === 0) return null;
    
    // Group thoughts by chain_id and find max event_time per chain
    const chainEventTimes = new Map<ChainId, number>();
    
    for (const thought of thoughts) {
      if (!thought.chain_id || thought.state !== 'anchored') continue;
      
      // Event time = COALESCE(anchored_at, created_at)
      const eventTime = new Date(thought.anchored_at || thought.created_at).getTime();
      const currentMax = chainEventTimes.get(thought.chain_id) || 0;
      
      if (eventTime > currentMax) {
        chainEventTimes.set(thought.chain_id, eventTime);
      }
    }
    
    // Find chain with most recent event_time
    let mostRecentChainId: ChainId | null = null;
    let mostRecentTime = 0;
    
    for (const [chainId, eventTime] of chainEventTimes) {
      if (eventTime > mostRecentTime) {
        mostRecentTime = eventTime;
        mostRecentChainId = chainId;
      }
    }
    
    return mostRecentChainId;
  }, [chains, thoughts]);

  /**
   * Deterministically select a chain when active_chain_id is null
   * Priority: most recent by thought event_time → first chain → create new
   */
  const selectDeterministicChain = useCallback(async (): Promise<ChainId | null> => {
    if (!user) return null;
    
    // 1. Try most recently updated chain by thought event_time
    const mostRecentChainId = getMostRecentChainByThoughtEventTime();
    if (mostRecentChainId) {
      return mostRecentChainId;
    }
    
    // 2. Fall back to first available chain (legacy/default)
    if (chains.length > 0) {
      return chains[0].id;
    }
    
    // 3. No chains exist - create a new one
    const newChainId = createChain(user.id);
    
    // Sync the new chain to Supabase immediately
    try {
      const now = new Date().toISOString();
      await supabase
        .from('thought_chains')
        .upsert({
          id: newChainId,
          user_id: user.id,
          created_at: now,
          updated_at: now,
          first_thought_at: null,
          display_label: null,
        }, { onConflict: 'id' });
    } catch (err) {
      console.error('Failed to create initial chain:', err);
    }
    
    return newChainId;
  }, [user, chains, getMostRecentChainByThoughtEventTime, createChain]);

  /**
   * Persist active_chain_id to user_settings (upsert-on-demand)
   */
  const persistActiveChainId = useCallback(async (chainId: ChainId | null) => {
    if (!user) return;
    
    // Skip if same as last persisted value
    if (chainId === lastPersistedChainIdRef.current) return;
    
    try {
      const { error } = await supabase
        .from('user_settings')
        .upsert({
          user_id: user.id,
          active_chain_id: chainId,
          updated_at: new Date().toISOString(),
        }, { onConflict: 'user_id' });

      if (error) throw error;
      
      lastPersistedChainIdRef.current = chainId;
    } catch (err) {
      console.error('Failed to persist active_chain_id:', err);
    }
  }, [user]);

  /**
   * Debounced persistence
   */
  const debouncedPersist = useCallback((chainId: ChainId | null) => {
    if (persistTimeoutRef.current) {
      clearTimeout(persistTimeoutRef.current);
    }
    persistTimeoutRef.current = setTimeout(() => {
      persistActiveChainId(chainId);
    }, PERSISTENCE_DEBOUNCE_MS);
  }, [persistActiveChainId]);

  /**
   * Load active_chain_id from user_settings and initialize
   */
  const initializeActiveChain = useCallback(async () => {
    if (!user || isInitializedRef.current) return;
    
    try {
      // Load user_settings row
      const { data, error } = await supabase
        .from('user_settings')
        .select('active_chain_id')
        .eq('user_id', user.id)
        .maybeSingle();

      if (error) throw error;

      let chainIdToActivate: ChainId | null = data?.active_chain_id || null;

      // If no active_chain_id, select deterministically
      if (!chainIdToActivate) {
        chainIdToActivate = await selectDeterministicChain();
        
        // Immediately upsert the selected chain
        if (chainIdToActivate) {
          await persistActiveChainId(chainIdToActivate);
        }
      } else {
        // Verify the chain exists (might have been deleted)
        const chainExists = chains.some(c => c.id === chainIdToActivate);
        if (!chainExists) {
          // Chain was deleted, select new one
          chainIdToActivate = await selectDeterministicChain();
          if (chainIdToActivate) {
            await persistActiveChainId(chainIdToActivate);
          }
        }
      }

      // Set active chain in store
      if (chainIdToActivate) {
        setActiveChain(chainIdToActivate);
        lastPersistedChainIdRef.current = chainIdToActivate;
      }
      
      isInitializedRef.current = true;
    } catch (err) {
      console.error('Failed to initialize active chain:', err);
      isInitializedRef.current = true; // Mark as initialized even on error to prevent loops
    }
  }, [user, chains, selectDeterministicChain, persistActiveChainId, setActiveChain]);

  // Initialize on mount (after chains are loaded)
  useEffect(() => {
    if (user && chains.length > 0 && !isInitializedRef.current) {
      initializeActiveChain();
    }
  }, [user, chains.length, initializeActiveChain]);

  // Handle case where no chains exist yet but user is logged in
  useEffect(() => {
    if (user && chains.length === 0 && !isInitializedRef.current) {
      // Wait a bit for chains to load, then create if still empty
      const timeoutId = setTimeout(async () => {
        if (chains.length === 0 && !isInitializedRef.current) {
          const chainId = await selectDeterministicChain();
          if (chainId) {
            setActiveChain(chainId);
            await persistActiveChainId(chainId);
          }
          isInitializedRef.current = true;
        }
      }, 2000);
      
      return () => clearTimeout(timeoutId);
    }
  }, [user, chains.length, selectDeterministicChain, setActiveChain, persistActiveChainId]);

  // Persist when activeChainId changes (after initialization)
  useEffect(() => {
    if (isInitializedRef.current && activeChainId !== lastPersistedChainIdRef.current) {
      debouncedPersist(activeChainId);
    }
  }, [activeChainId, debouncedPersist]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (persistTimeoutRef.current) {
        clearTimeout(persistTimeoutRef.current);
      }
    };
  }, []);

  // Reset initialization flag when user changes (logout/login)
  useEffect(() => {
    if (!user) {
      isInitializedRef.current = false;
      lastPersistedChainIdRef.current = null;
    }
  }, [user]);

  return {
    initializeActiveChain,
    persistActiveChainId,
    getMostRecentChainByThoughtEventTime,
  };
}

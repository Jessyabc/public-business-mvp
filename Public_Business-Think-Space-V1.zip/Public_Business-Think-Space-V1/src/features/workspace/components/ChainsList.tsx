/**
 * Think Space: All Chains View
 * 
 * Lists all chains ordered by last thought event_time.
 * Shows preview text from most recent thought.
 * Tap to switch to that chain.
 * 
 * Order: MAX(COALESCE(anchored_at, created_at)) per chain, descending
 */

import { useMemo, useCallback } from 'react';
import { useWorkspaceStore } from '../useWorkspaceStore';
import { useChainStore } from '../stores/chainStore';
import { cn } from '@/lib/utils';
import { format, parseISO, isToday, isYesterday, isThisWeek, isThisYear } from 'date-fns';
import { Link2, X, Plus } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import type { ThoughtChain, ChainId } from '../types/chain';

interface ChainsListProps {
  isOpen: boolean;
  onClose: () => void;
}

interface ChainWithMeta {
  chain: ThoughtChain;
  lastEventTime: Date;
  thoughtCount: number;
  previewText: string;
}

/**
 * Format chain label for display
 */
function formatChainLabel(chain: ThoughtChain, lastEventTime: Date): string {
  if (chain.display_label) return chain.display_label;
  
  if (isToday(lastEventTime)) {
    return format(lastEventTime, 'h:mm a');
  }
  if (isYesterday(lastEventTime)) {
    return `Yesterday, ${format(lastEventTime, 'h:mm a')}`;
  }
  if (isThisWeek(lastEventTime)) {
    return format(lastEventTime, 'EEEE');
  }
  if (isThisYear(lastEventTime)) {
    return format(lastEventTime, 'MMMM d');
  }
  return format(lastEventTime, 'MMMM d, yyyy');
}

/**
 * Get preview text from thought content
 */
function getPreviewText(content: string, maxLength: number = 60): string {
  if (!content) return 'Empty chain';
  const trimmed = content.trim().replace(/\n+/g, ' ');
  if (trimmed.length <= maxLength) return trimmed;
  return trimmed.slice(0, maxLength).trim() + '...';
}

export function ChainsList({ isOpen, onClose }: ChainsListProps) {
  const { user } = useAuth();
  const { thoughts } = useWorkspaceStore();
  const { chains, activeChainId, setActiveChain, createChain } = useChainStore();

  /**
   * Compute chains with metadata, ordered by last thought event_time
   * Uses MAX(COALESCE(anchored_at, created_at)) per chain
   */
  const chainsWithMeta = useMemo((): ChainWithMeta[] => {
    // Build map of chain_id -> { lastEventTime, thoughtCount, latestThought }
    const chainMeta = new Map<ChainId, { 
      lastEventTime: number; 
      thoughtCount: number; 
      latestThought: string;
    }>();
    
    // Initialize with all chains (even empty ones)
    for (const chain of chains) {
      chainMeta.set(chain.id, {
        lastEventTime: new Date(chain.created_at).getTime(),
        thoughtCount: 0,
        latestThought: '',
      });
    }
    
    // Process anchored thoughts to compute max event_time per chain
    for (const thought of thoughts) {
      if (!thought.chain_id || thought.state !== 'anchored') continue;
      
      const eventTime = new Date(thought.anchored_at || thought.created_at).getTime();
      const existing = chainMeta.get(thought.chain_id);
      
      if (existing) {
        existing.thoughtCount++;
        if (eventTime > existing.lastEventTime) {
          existing.lastEventTime = eventTime;
          existing.latestThought = thought.content;
        }
      }
    }
    
    // Convert to array and sort by lastEventTime descending
    const result: ChainWithMeta[] = [];
    
    for (const chain of chains) {
      const meta = chainMeta.get(chain.id);
      if (meta) {
        result.push({
          chain,
          lastEventTime: new Date(meta.lastEventTime),
          thoughtCount: meta.thoughtCount,
          previewText: getPreviewText(meta.latestThought),
        });
      }
    }
    
    // Sort by lastEventTime descending (most recent first)
    result.sort((a, b) => b.lastEventTime.getTime() - a.lastEventTime.getTime());
    
    return result;
  }, [chains, thoughts]);

  // Handle chain selection
  const handleChainSelect = useCallback((chainId: ChainId) => {
    setActiveChain(chainId);
    onClose();
  }, [setActiveChain, onClose]);

  // Handle create new chain
  const handleCreateChain = useCallback(() => {
    if (!user) return;
    const newChainId = createChain(user.id);
    setActiveChain(newChainId);
    onClose();
  }, [user, createChain, setActiveChain, onClose]);

  if (!isOpen) return null;

  return (
    <>
      {/* Overlay */}
      <div
        className="fixed inset-0 bg-black/20 backdrop-blur-sm z-40 md:bg-transparent"
        onClick={onClose}
        data-testid="chains-list-overlay"
      />
      
      {/* Sidebar */}
      <div
        className={cn(
          "fixed top-0 right-0 h-full w-72 z-50",
          "bg-[#F5F0EB] shadow-2xl",
          "transition-transform duration-300 ease-out",
          "overflow-y-auto",
          isOpen ? "translate-x-0" : "translate-x-full"
        )}
        style={{
          boxShadow: `
            4px 0 16px rgba(166, 150, 130, 0.15),
            inset -1px 0 0 rgba(255, 255, 255, 0.5)
          `
        }}
        data-testid="chains-list-sidebar"
      >
        {/* Header */}
        <div className="sticky top-0 bg-[#F5F0EB] border-b border-[#E0D9D0] px-4 py-3 flex items-center justify-between z-10">
          <div className="flex items-center gap-2">
            <Link2 className="w-4 h-4" style={{ color: '#6B635B' }} />
            <h2 className="text-sm font-semibold" style={{ color: '#3D3833' }}>
              All Chains
            </h2>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleCreateChain}
              className="p-1.5 rounded-lg hover:bg-[#EAE5E0] transition-colors"
              aria-label="Create new chain"
              data-testid="create-chain-btn"
            >
              <Plus className="w-4 h-4" style={{ color: '#489FE3' }} />
            </button>
            <button
              onClick={onClose}
              className="p-1 rounded-lg hover:bg-[#EAE5E0] transition-colors"
              aria-label="Close chains list"
              data-testid="close-chains-btn"
            >
              <X className="w-4 h-4" style={{ color: '#6B635B' }} />
            </button>
          </div>
        </div>

        {/* Chains List */}
        <div className="px-2 py-4 space-y-1">
          {chainsWithMeta.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-sm opacity-50" style={{ color: '#6B635B' }}>
                No chains yet
              </p>
              <button
                onClick={handleCreateChain}
                className="mt-4 px-4 py-2 rounded-lg text-sm font-medium"
                style={{ 
                  color: '#489FE3',
                  background: 'rgba(72, 159, 227, 0.1)',
                }}
                data-testid="create-first-chain-btn"
              >
                Start your first chain
              </button>
            </div>
          ) : (
            chainsWithMeta.map(({ chain, lastEventTime, thoughtCount, previewText }) => {
              const isActive = chain.id === activeChainId;
              const label = formatChainLabel(chain, lastEventTime);
              
              return (
                <button
                  key={chain.id}
                  onClick={() => handleChainSelect(chain.id)}
                  className={cn(
                    "w-full text-left px-3 py-3 rounded-lg",
                    "transition-all duration-200",
                    "hover:bg-[#EAE5E0] active:scale-[0.98]",
                    isActive && "bg-[#EAE5E0] ring-1 ring-[#489FE3]/30"
                  )}
                  data-testid={`chain-item-${chain.id}`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span
                      className={cn(
                        "text-sm font-medium truncate flex-1",
                        isActive && "text-[#489FE3]"
                      )}
                      style={{ color: isActive ? '#489FE3' : '#3D3833' }}
                    >
                      {label}
                    </span>
                    <span
                      className="text-xs ml-2 shrink-0 opacity-60"
                      style={{ color: '#6B635B' }}
                    >
                      {thoughtCount}
                    </span>
                  </div>
                  <p
                    className="text-xs truncate opacity-60"
                    style={{ color: '#9A8F85' }}
                  >
                    {previewText}
                  </p>
                  {isActive && (
                    <div 
                      className="mt-1.5 text-[10px] font-medium"
                      style={{ color: '#489FE3' }}
                    >
                      Currently writing
                    </div>
                  )}
                </button>
              );
            })
          )}
        </div>
      </div>
    </>
  );
}
